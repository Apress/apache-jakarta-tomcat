create database tomcatsessions;

use tomcatsessions;

create table sessions
(
  id varchar(100) not null primary key,
  valid char(1) not null,
  maxinactive int not null,
  lastaccess bigint,
  data mediumblob
);
