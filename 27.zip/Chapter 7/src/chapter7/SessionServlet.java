package chapter7;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionServlet extends HttpServlet {

  public void doGet(HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException {

      response.setContentType("text/html");

      PrintWriter out = response.getWriter();
      out.println("<html>");
      out.println("<body bgcolor=\"white\">");
      out.println("<head>");

      out.println("<title>Session Servlet</title>");
      out.println("</head>");
      out.println("<body>");

      // Get a reference to the HttpSession Object
      HttpSession session = request.getSession();

      // Print the current Session's ID
      out.println("Session ID:" + " " + session.getId());
      out.println("<br>");

      // Print the current Session's Creation Time
      out.println("Session Created:" + " " +
        new Date(session.getCreationTime()) + "<br>");

      // Print the current Session's Last Access Time
      out.println("Session Last Accessed" + " " +
        new Date(session.getLastAccessedTime()));

      // Get the name/value pair to be placed in the HttpSession
      String dataName = request.getParameter("name");
      String dataValue = request.getParameter("value");

      if ( dataName != null && dataValue != null ) {

        // If the Parameter Values are not null
        // then add the name/value pair to the HttpSession
        session.setAttribute(dataName, dataValue);
      }

      out.println("<P>");
      out.println("Sessions Attributes" + "<br>");

      // Get all of the Attribute Names from the HttpSession
      Enumeration names = session.getAttributeNames();

      while ( names.hasMoreElements() ) {

          String name = (String) names.nextElement();
          // Get the Attribute Value with the matching name
          String value = session.getAttribute(name).toString();
          // Print the name/value pair
          out.println(name + " = " + value + "<br>");
      }

      // Create a Form to Add name/value pairs to the HttpSession
      out.println("<P>GET based form:<br>");
      out.print("<form action=\"");
	    out.print(response.encodeURL("chapter7.SessionServlet"));
      out.print("\" ");
      out.println("method=GET>");
      out.println("Session Attribute:");
      out.println("<input type=text size=20 name=name>");
      out.println("<br>");
      out.println("Session Value:");
      out.println("<input type=text size=20 name=value>");
      out.println("<br>");
      out.println("<input type=submit>");
      out.println("</form>");

      out.println("</body>");
      out.println("</html>");
  }
}