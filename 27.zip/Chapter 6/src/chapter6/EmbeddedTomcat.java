package chapter6;

import java.net.URL;

import org.apache.catalina.Connector;
import org.apache.catalina.Context;
import org.apache.catalina.Deployer;
import org.apache.catalina.Engine;
import org.apache.catalina.Host;
import org.apache.catalina.logger.SystemOutLogger;
import org.apache.catalina.startup.Embedded;
import org.apache.catalina.Container;

public class EmbeddedTomcat {

  private String path = null;

  private Embedded embedded = null;
  private Host host = null;

  /**
    * Default Constructor
    *
    */
  public EmbeddedTomcat() {

  }

  /**
    * Basic Accessor setting the value of the context path
    *
    * @param        path - the path
    */
  public void setPath(String path) {

    this.path = path;
  }

  /**
    * Basic Accessor returning the value of the context path
    *
    * @return - the context path
    */
  public String getPath() {

    return path;
  }

  /**
    * This method Starts the Tomcat server.
    */
  public void startTomcat() throws Exception {

    Engine engine = null;

    // Set the home directory
    System.setProperty("catalina.home", getPath());

    // Create an embedded server
    embedded = new Embedded();
    embedded.setDebug(5);
    embedded.setLogger(new SystemOutLogger());

    // Create an engine
    engine = embedded.createEngine();
    engine.setDefaultHost("localhost");

    // Create a default virtual host
    host = embedded.createHost("localhost", getPath() + "/webapps");
    engine.addChild(host);

    // Create the ROOT context
    Context context = embedded.createContext("",
      getPath() + "/webapps/ROOT");
    host.addChild(context);

    // Create the examples context
    Context examplesContext = embedded.createContext("/examples",
      getPath() + "/webapps/examples");
    host.addChild(examplesContext);

    // Install the assembled container hierarchy
    embedded.addEngine(engine);

    // Assemble and install a default HTTP connector
    Connector connector = embedded.createConnector(null, 8080, false);
    embedded.addConnector(connector);

    // Start the embedded server
    embedded.start();
  }

  /**
    * This method Stops the Tomcat server.
    */
  public void stopTomcat() throws Exception {

    // Stop the embedded server
    embedded.stop();
  }

  /**
    * Registers a WAR
    *
    * @param contextPath - the context path under which the
    *               application will be registered
    * @param url - the URL of the WAR file to be registered.
    */
  public void registerWAR(String contextPath, URL url) throws Exception {

    if ( contextPath == null ) {

      throw new Exception("Invalid Path : " + contextPath);
    }
    String displayPath = contextPath;
    if( contextPath.equals("/") ) {

      contextPath = "";
    }

    if ( url == null ) {

      throw new Exception("Invalid WAR : " + url);
    }

    Deployer deployer = (Deployer)host;
    Context context = deployer.findDeployedApp(contextPath);

    if (context != null) {

      throw new Exception("Context " + contextPath + " already Exists!");
    }
    deployer.install(contextPath, url);
  }

  /**
    * removes a WAR
    *
    * @param contextPath - the context path to be removed
    */
  public void unregisterWAR(String contextPath) throws Exception {

    Context context = host.map(contextPath);
    if ( context != null ) {

      embedded.removeContext(context);
    }
    else {

      throw new Exception("Context does not exist for named path : "
        + contextPath);
    }
  }

  public static void main(String args[]) {

    try {

      EmbeddedTomcat tomcat = new EmbeddedTomcat();
      tomcat.setPath("d:/EmbeddedTomcat");

      tomcat.startTomcat();

      Thread.sleep(100000);

      tomcat.stopTomcat();

      System.exit(0);
    }
    catch( Exception e ) {

      e.printStackTrace();
    }
  }
}
