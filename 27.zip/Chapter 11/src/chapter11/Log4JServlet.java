package chapter11;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import org.apache.log4j.PropertyConfigurator;

public class Log4JServlet extends HttpServlet {

  public void init()
    throws ServletException {

    // Get Fully Qualified Path to Properties File
    String path = getServletContext().getRealPath("/");
    String propfile = path + getInitParameter("propfile");

    // Initialize Properties for All Servlets
    PropertyConfigurator.configure(propfile);
  }

  public void doGet(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {

    PrintWriter out = response.getWriter();


    out.println("<html>");
    out.println("<head><title>Log4JServlet</title></head>");
    out.println("<body>");
    out.println("<p>The servlet has received a GET. This is the reply.</p>");
    out.println("</body></html>");
  }

  public void destroy() {

  }
}