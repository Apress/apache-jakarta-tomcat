package chapter11;

import org.apache.log4j.Category;
import org.apache.log4j.Priority;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

public class Log4JApp {

  // Get an instance of the chapter11.Log4JApp Category
  static Category cat =
    Category.getInstance("chapter11.Log4JApp");
  // Get an instance of the chapter11.Log4JApp.child Category
  // which is a child of chapter11.Log4JApp
  static Category childcat =
    Category.getInstance("chapter11.Log4JApp.child");

  public static void main(String[] args) {

    // Load the properties using the PropertyConfigurator
    PropertyConfigurator.configure("properties.lcf");

    // Log Messages using the Parent Category
    cat.debug("This is a log message from the " +
      cat.getName());
    cat.info("This is a log message from the " +
      cat.getName());
    cat.warn("This is a log message from the " +
      cat.getName());
    cat.error("This is a log message from the " +
      cat.getName());
    cat.fatal("This is a log message from the " +
      cat.getName());

    // Log Messages using the Child Category
    childcat.debug("This is a log message from the " +
      childcat.getName());
    childcat.info("This is a log message from the " +
      childcat.getName());
    childcat.warn("This is a log message from the " +
      childcat.getName());
    childcat.error("This is a log message from the " +
      childcat.getName());
    childcat.fatal("This is a log message from the " +
      childcat.getName());
  }
}