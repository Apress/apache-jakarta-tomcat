create database tomcatusers;

use tomcatusers;

create table users
(
  user_name varchar(15) not null primary key,
  user_pass varchar(15) not null
);

create table roles
(
  role_name varchar(15) not null primary key
);

create table user_roles
(
  user_name varchar(15) not null,
  role_name varchar(15) not null,
  primary key(user_name, role_name)
);

insert into users values("bob", "password");
insert into users values("joe", "$joe$");
insert into users values("robert", "password");
insert into users values("tomcat", "password");

insert into roles values("apressuser");
insert into roles values("manager");
insert into roles values("tomcat");

insert into user_roles values("bob", "manager");
insert into user_roles values("joe", "apressuser");
insert into user_roles values("joe", "manager");
insert into user_roles values("robert", "apressuser");
insert into user_roles values("tomcat", "tomcat");
