package chapter8;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public final class ExampleFilter implements Filter {

  public void init(FilterConfig config)
    throws javax.servlet.ServletException {

    System.err.println("---->ExampleFilter: INSIDE INIT<----");
  }

  public void destroy() {

    System.err.println("---->ExampleFilter: INSIDE DESTROY<----");
  }

  public void doFilter(ServletRequest request,
    ServletResponse response,
    FilterChain chain)
    throws java.io.IOException, javax.servlet.ServletException {

    System.err.println("---->ExampleFilter: Before doFilter()<----");

		request.setAttribute("logo",
      new String("/apress/images/monitor2.gif"));

    chain.doFilter(request, response);

    System.err.println("---->ExampleFilter: After doFilter()<----");
  }
}
