package chapter8;

import javax.servlet.Filter;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import java.io.PrintWriter;

public class ExampleFilter2 implements Filter {

  public ExampleFilter2() {

  }

  public void init(FilterConfig config)
    throws javax.servlet.ServletException {

    System.err.println("---->ExampleFilter2: INSIDE INIT<----");
  }

  public void destroy() {

    System.err.println("---->ExampleFilter2: INSIDE DESTROY<----");
  }

  public void doFilter(ServletRequest request,
    ServletResponse response,
    FilterChain chain)
    throws java.io.IOException, javax.servlet.ServletException {

    System.err.println("---->ExampleFilter2: Before doFilter()<----");
    chain.doFilter(request, response);
    System.err.println("---->ExampleFilter2: After doFilter()<----");

    PrintWriter out = response.getWriter();
    out.write("\n<!-- Created by the Apress Application -->\n");
  }
}
