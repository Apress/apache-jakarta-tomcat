package chapter10;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class LoginAction extends Action {

  protected String getUser(String username, String password) {

    String user = null;

    // You would normally do some real User lookup here, but
    // for this example we will have only one valid username "bob"
    System.err.println(username + ":" + password);
    if ( username.equals("bob") && password.equals("password") ) {

      user = new String("Bob");
    }
    return user;
  }

	public ActionForward perform(ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws IOException, ServletException {

    String user = null;

		// Default target to success
    String target = new String("success");

    // Use the LoginForm to get the request parameters
	  String username = ((LoginForm)form).getUsername();
	  String password = ((LoginForm)form).getPassword();

    user = getUser(username, password);

    // Set the target to failure
    if ( user == null ) {

      target = new String("failure");
    }
    else {

      request.setAttribute("USER", user);
    }
	  // Forward to the appropriate View
	  return (mapping.findForward(target));
	}
}
