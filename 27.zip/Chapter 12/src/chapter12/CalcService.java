package chapter12;

public class CalcService {

  public int add(int p1, int p2) {

    return p1 + p2;
  }

  public int subtract(int p1, int p2) {

    return p1 - p2;
  }
}