package chapter2;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class login extends HttpServlet {

  private String target = "/welcome.jsp";

  private String getUser(String username, String password) {

    // Just return a statice name
    // If this was reality, we would perform a SQL lookup
    return "Bob";
  }

  public void init(ServletConfig config)
    throws ServletException {

    super.init(config);
  }

  public void doGet(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {

    // If it is a get request forward to doPost()
    doPost(request, response);
  }

  public void doPost(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {

    // Get the username from the request
    String username = request.getParameter("username");
    // Get the password from the request
    String password = request.getParameter("password");

    String user = getUser(username, password);

    // Add the fake user to the request
    request.setAttribute("USER", user);

    // Forward the request to the target named
    ServletContext context = getServletContext();

    System.err.println("Redirecting to " + target);
    RequestDispatcher dispatcher =
      context.getRequestDispatcher(target);
    dispatcher.forward(request, response);
  }

  public void destroy() {
  }
}
