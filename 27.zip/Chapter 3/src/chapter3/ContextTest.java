package chapter3;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ContextTest extends HttpServlet {

  private static final String CONTENT_TYPE = "text/html";

  public void init() throws ServletException {

  }

  public void doGet(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {

    doPost(request, response);
  }

  public void doPost(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {

    // Get a reference to the ServletContext
    ServletContext context = getServletContext();
    // Try to get the count attribute from the ServletContext
    Integer count = (Integer)context.getAttribute("count");

    // If there was no attribute count, then create
    // one and add it to the ServletContext
    if ( count == null ) {

      count = new Integer(0);
      context.setAttribute("count", new Integer(0));
    }

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>ContextTest</title></head>");
    out.println("<body>");
    // Output the current value of the attribute count
    out.println("<p>The current COUNT is : " + count + ".</p>");
    out.println("</body></html>");

    // Increment the value of the count attribute
    count = new Integer(count.intValue() + 1);
    // Add the new value of count to the ServletContext
    context.setAttribute("count", count);
  }

  public void destroy() {
  }
}